﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Memory;
using Operation;

namespace WPFMVVMDemo.ViewModel.Symbol
{
  public  class AddSingle :  IJudge.JudgeForSingle
    {
        //添加单目符号，并进行运算
        public string JudgeForSinge(string single)
        {
            Complex_Operation CO = new Complex_Operation();
            return "";
            
        }
    }
    }

