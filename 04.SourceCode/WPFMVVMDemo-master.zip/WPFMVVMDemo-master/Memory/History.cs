﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace WPFMVVMDemo.ViewModel.History
{
    //历史记录
   public class History_Memory
    {
        
        List<string> list = new List<string>();

        public void AddStorage() { }
        public void Remove() { }
        public void clear() { }
    }
}
