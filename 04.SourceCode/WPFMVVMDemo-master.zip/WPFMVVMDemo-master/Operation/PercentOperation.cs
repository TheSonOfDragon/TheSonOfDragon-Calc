﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Memory;

namespace Operation
{
    //百分号运算
    class Percent_Operation
    {
        //归零运算
        public double MakeZero(double num1)
        {
            return 0;
        }
        //百分比运算
        public double percent(double num1)
        {
            return num1 / 100;
        }

    }

}
